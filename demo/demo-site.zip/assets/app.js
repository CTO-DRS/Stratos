console.log("hello from stratos demo");
